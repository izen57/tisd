#ifndef _STACK_UTILS_H_
#define _STACK_UTILS_H_
long long int scan_value(const int mode);
#endif